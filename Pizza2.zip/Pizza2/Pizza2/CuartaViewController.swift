//
//  CuartaViewController.swift
//  Pizza2
//
//  Created by LEONEL HERNANDEZ PEREZ on 09/02/17.
//  Copyright © 2017 LeonelHP. All rights reserved.
//

import UIKit

class CuartaViewController: UIViewController {
    
    @IBOutlet weak var IngJam: UILabel!
    @IBOutlet weak var IngPep: UILabel!
    @IBOutlet weak var IngSal: UILabel!
    @IBOutlet weak var IngCha: UILabel!
    @IBOutlet weak var IngPin: UILabel!




    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    
    @IBAction func LimpiarIng(_ sender: Any) {
        IngJam.text = "-"
        IngPep.text = "-"
        IngSal.text = "-"
        IngCha.text = "-"
        IngPin.text = "-"
    }
    
    
    @IBAction func AgregaJam(_ sender: Any) {
                IngJam.text = "Si"
    }
    
    @IBAction func AgregaPep(_ sender: Any) {
                IngPep.text = "Si"
    }
    
    @IBAction func AgregaSal(_ sender: Any) {
                IngSal.text = "Si"
    }
    
    @IBAction func AgregaCha(_ sender: Any) {
                IngCha.text = "Si"
    }
    
    @IBAction func AgregaPin(_ sender: Any) {
                IngPin.text = "Si"
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
}

