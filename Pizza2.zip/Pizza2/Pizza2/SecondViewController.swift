//
//  SecondViewController.swift
//  Pizza2
//
//  Created by LEONEL HERNANDEZ PEREZ on 31/01/17.
//  Copyright © 2017 LeonelHP. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    
    @IBOutlet weak var Picker2: UIPickerView!
    @IBOutlet weak var Tex2: UILabel!

    
    var arrayPicker2 = ["Selecciona","Delgada","Crujiente","Gruesa"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.Picker2.dataSource = self
        self.Picker2.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrayPicker2.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrayPicker2[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        Tex2.text = arrayPicker2[row]
        //Label1.text = String(row)
        //Label1.text = arrayPicker1[row]
    }

    

}

