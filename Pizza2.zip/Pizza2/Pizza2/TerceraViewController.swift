//
//  TerceraViewController.swift
//  Pizza2
//
//  Created by LEONEL HERNANDEZ PEREZ on 31/01/17.
//  Copyright © 2017 LeonelHP. All rights reserved.
//

import UIKit

class TerceraViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    

    @IBOutlet weak var Picker3: UIPickerView!
    @IBOutlet weak var Tex3: UILabel!
    
    
    var arrayPicker3 = ["Selecciona","Mozarela","Chedar","Parmesano","Sin queso"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.Picker3.dataSource = self
        self.Picker3.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrayPicker3.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrayPicker3[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        Tex3.text = arrayPicker3[row]
        //Label1.text = String(row)
        //Label1.text = arrayPicker1[row]
    }
    
    
    
    
}
